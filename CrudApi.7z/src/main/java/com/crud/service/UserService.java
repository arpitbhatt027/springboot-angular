package com.crud.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.crud.entity.User;
import com.crud.repository.UserRepository;
import com.crud.request.UserRequest;
import com.crud.request.UserUpdateRequest;
import com.crud.response.UserResponse;

@Service
public class UserService {

	@Autowired
	private UserRepository userRepository;

	public List<UserResponse> getAll() {
		List<User> users = userRepository.findAll();

		List<UserResponse> userResponseList = new ArrayList<UserResponse>();

		for (int i = 0; i < users.size(); i++) {
			UserResponse userResponse = new UserResponse();
			userResponse.setUserId(users.get(i).getUserId());
			userResponse.setName(users.get(i).getName());
			userResponse.setEmail(users.get(i).getEmail());
			userResponse.setMobileNumber(users.get(i).getMobileNumber());

			userResponseList.add(userResponse);
		}

		return userResponseList;
	}

	public UserResponse getUserById(int userId) {
		Optional<User> userOptional = userRepository.findById(userId);
		if (userOptional.isPresent()) {
			User user = userOptional.get();
			UserResponse userResponse = new UserResponse();
			userResponse.setUserId(user.getUserId());
			userResponse.setName(user.getName());
			userResponse.setEmail(user.getEmail());
			userResponse.setMobileNumber(user.getMobileNumber());

			return userResponse;
		} else {
			return new UserResponse();
		}
	}

	public UserResponse createUser(UserRequest userRequest) {
		User user = new User();
		user.setName(userRequest.getName());
		user.setEmail(userRequest.getEmail());
		user.setMobileNumber(userRequest.getMobileNumber());

		User savedUser = userRepository.save(user);

		UserResponse userResponse = new UserResponse();
		userResponse.setUserId(savedUser.getUserId());
		userResponse.setName(savedUser.getName());
		userResponse.setEmail(savedUser.getEmail());
		userResponse.setMobileNumber(savedUser.getMobileNumber());

		return userResponse;
	}

	public UserResponse updateUser(UserUpdateRequest updateRequest) {
		User user = new User();
		user.setUserId(updateRequest.getUserId());
		user.setName(updateRequest.getName());
		user.setEmail(updateRequest.getEmail());
		user.setMobileNumber(updateRequest.getMobileNumber());

		User updatedUser = userRepository.save(user);
		UserResponse userResponse = new UserResponse();
		userResponse.setUserId(updatedUser.getUserId());
		userResponse.setName(updatedUser.getName());
		userResponse.setEmail(updatedUser.getEmail());
		userResponse.setMobileNumber(updatedUser.getMobileNumber());

		return userResponse;
	}

	public void deleteUser(int userId) {
		userRepository.deleteById(userId);
	}

}
