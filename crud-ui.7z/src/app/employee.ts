export class Employee {
    userId!: number;
    name: string | undefined;    
    email: string | undefined;
    mobileNumber: string | undefined;
    active!: boolean;
}